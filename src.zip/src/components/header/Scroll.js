
const Scroll=()=>{
let one = document.querySelector("#section1");
let two = document.querySelector("#section2");
let three =document.querySelector("#section3");
let lp = document.querySelector(".latestposts");
let allButtons = document.querySelectorAll("button");
for(let i=0;i<allButtons.length;i++){
  allButtons[i].addEventListener("click",function(){
    if(i===0){
      one.scrollIntoView();
    }
    else if(i===1){
      two.scrollIntoView();
    }
    else if(i===2){
      three.scrollIntoView();
    }
    else{
      lp.scrollIntoView();
    }
  })
}}
export default Scroll;