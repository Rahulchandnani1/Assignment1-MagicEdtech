
function Header() {

	return (<div>
		
		<header>
			<nav>
				<div class="logo-container">
					<span class="logo"></span>Bloggers
				</div>
				<div class="links-container">
					<button>Section1</button>
					<button>Section2</button>
					<button>Section3</button>
					<button>Latest Posts</button>

				</div>
				<div class="search-container">

					<button onClick='window.location="test project.html"'>signup</button>
				</div>
			</nav>
		</header>

</div>
	);
}

export default Header;

