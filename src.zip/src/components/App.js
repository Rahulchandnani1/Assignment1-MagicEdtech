
import './App.css';
import ice from '../components/ice.png';
import Header from './header';
import BlogList from './BlogList';

function App() {
  return (
    
<div className="App">      

<Header />

<div class="img-container">
<img
  src={ice}
 
/>
<div class="img">Sample Design</div>
</div>
<main>
  <BlogList/>
</main>


    </div>
  );
}

export default App;
