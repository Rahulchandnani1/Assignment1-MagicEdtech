import data from "./p.js";
import React from 'react';
import './b.css';
const BlogList =()=>{

    return(
        <main>
            
<div class="post-conatiner">
<div class="flex-item-left">
<h3>Latest Posts</h3>
</div>
<div class="flex-item-right" id="post1">
    {data.map(post =>{return(<>
    
    <div key={post.id}>
        <h5>
            Insights
        </h5>
        <h4>
            {post.name}
        </h4><p>{post.name}</p>
        <h5>created by:<a href="https://www.google.com">{post.email}</a></h5>
        <hr />
    </div>
    </>);})}
</div>
</div>
        <div class="section-container" id="section1">



    <div class="section" id="section1" name="section1">
    <div class="heading">
    <h3>Section 1</h3><br/></div>
    <div class="blog">
    <div>
    <h5>Blog1</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog2</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod  </p></div>
    <div>
    <h5>Blog3</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod  </p></div>
    <div>
    <h5>Blog4</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod  </p></div>
    </div>
    </div>
    
    <div class="section" id="section2" name="section2">
    <div class="heading">
    <h3>Section 2</h3><br/></div>
    <div class="blog">
    <div>
    <h5>Blog1</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog2</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog3</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog4</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    </div>
    </div>
    
    <div class="section" id="section3" name="section3">
    <div class="heading">
    <h3>Section 3</h3><br/></div>
    <div class="blog">
    <div>
    <h5>Blog1</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog2</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog3</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    <div>
    <h5>Blog4</h5>
    <p>est natus enim nihil est dolore omnis voluptatem numquam\net omnis occaecati quod </p></div>
    </div>
    </div>
    </div>
    
    <section>
   <footer>
    <div class="f-container">
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    <div class="inlink">
    <a href="#">Link1</a>
    <a href="#">Link2</a>
    <a href="#">Link3</a></div>
    </div>
    </footer>
    </section>
    </main>
    );
}

export default BlogList;